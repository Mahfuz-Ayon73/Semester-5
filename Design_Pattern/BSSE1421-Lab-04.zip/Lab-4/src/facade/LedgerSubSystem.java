package facade;

public class LedgerSubSystem {
	
	   public void makeEntry(String cardNumber, double amount) {
		   
	        System.out.println("Making ledger entry for card: " + cardNumber + " with amount: " + amount);
	        
	    }
	   
	   
}
