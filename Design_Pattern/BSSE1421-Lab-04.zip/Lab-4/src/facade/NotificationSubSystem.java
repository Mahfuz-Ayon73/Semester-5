package facade;

public class NotificationSubSystem {
	
	public void sendNotification(String message) {
        System.out.println("Sending notification: " + message);
        
    }
}
