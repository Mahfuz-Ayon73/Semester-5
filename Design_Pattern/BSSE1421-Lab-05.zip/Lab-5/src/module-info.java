/**
 * 
 */
/**
 * 
 */
module Lab_5 {
}