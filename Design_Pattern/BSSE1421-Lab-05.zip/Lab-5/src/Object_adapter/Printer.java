package Object_adapter;

public interface Printer {
    void printDocument(String document);
}
