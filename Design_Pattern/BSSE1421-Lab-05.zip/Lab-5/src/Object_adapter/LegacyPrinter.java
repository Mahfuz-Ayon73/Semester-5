package Object_adapter;

public class LegacyPrinter {

	public void printDocument(String document) {
		
        System.out.println("Document printing from legacy printer" + document);
        
    }
     
}
