package Object_adapter;

public class Main {

	public static void main(String[] args) {
		
		 PrinterManagement printerManagement = new PrinterManagement();
	        
	     printerManagement.print("Modern document");
	     
	     //printerManagement.print("");

	}

}
