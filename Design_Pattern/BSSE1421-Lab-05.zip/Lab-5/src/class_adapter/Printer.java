package class_adapter;

public interface Printer {
	
	void printDocument(String text);
	
}

