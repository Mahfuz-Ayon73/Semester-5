package class_adapter;

public class LegacyPrinter{
	
	 public void printDocument(String text) {
		 
	        System.out.println("Document Printing by Legacy Printer: " + text);
	        
	 }
}
