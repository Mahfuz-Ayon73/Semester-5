package class_adapter;

public class ModernPrinter implements Printer {
	
	 public void printDocument(String text) {
		 
	        System.out.println("Modern Document: " + text);
	        
	 }
}
