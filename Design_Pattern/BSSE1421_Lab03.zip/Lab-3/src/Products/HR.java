package Products;

import Interfaces.Departments;

public class HR implements Departments {

	@Override
	public void doSomething() {
		System.out.print("HR dept");
		
	}

}
