package Interfaces;

public interface Departments {
     void doSomething();
}
