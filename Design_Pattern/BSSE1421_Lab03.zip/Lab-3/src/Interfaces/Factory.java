package Interfaces;

public interface Factory {
     
}
