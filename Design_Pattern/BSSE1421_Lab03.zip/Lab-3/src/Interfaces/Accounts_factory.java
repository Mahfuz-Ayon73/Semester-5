package Interfaces;

public interface Accounts_factory {

}
