package Interfaces;

public interface HR_factory {

}
