/**
 * 
 */
/**
 * 
 */
module Lab_2 {
}