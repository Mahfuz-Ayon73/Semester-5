package factory;

public class MordernTable implements Table{

	@Override
	public void putOnTable() {
		
		System.out.println("Put on Mordern Table");
		
	}

}
