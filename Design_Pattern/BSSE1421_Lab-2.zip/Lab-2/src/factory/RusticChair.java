package factory;

public class RusticChair implements Chair{

	@Override
	public void sitOnChair() {
		
		System.out.println("Sit on Rustic Chair");
		
	}

}
