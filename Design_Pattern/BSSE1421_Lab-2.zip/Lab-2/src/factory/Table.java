package factory;

public interface Table {
     void putOnTable();
}
