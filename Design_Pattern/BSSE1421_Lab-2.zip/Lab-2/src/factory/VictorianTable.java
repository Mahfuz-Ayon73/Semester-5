package factory;

public class VictorianTable implements Table{

	@Override
	public void putOnTable() {
		
		System.out.println("Put on Victorian Table");
		
	}

}
