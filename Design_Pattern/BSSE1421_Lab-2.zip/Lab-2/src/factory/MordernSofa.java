package factory;

public class MordernSofa implements Sofa{

	@Override
	public void sitOnSofa() {
		
		System.out.println("Sit on Mordern Sofa");
		
	}

}
