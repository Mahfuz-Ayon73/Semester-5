package factory;

public class RusticTable implements Table{

	@Override
	public void putOnTable() {
		
		System.out.println("Put on Rustic Table");
	}

}
