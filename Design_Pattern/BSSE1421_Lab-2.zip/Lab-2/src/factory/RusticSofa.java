package factory;

public class RusticSofa implements Sofa{

	@Override
	public void sitOnSofa() {
		
		System.out.println("Sit on Rustic Sofa");
		
	}

}
