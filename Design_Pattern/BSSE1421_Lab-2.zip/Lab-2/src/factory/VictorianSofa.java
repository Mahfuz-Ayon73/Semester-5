package factory;

public class VictorianSofa implements Sofa{

	@Override
	public void sitOnSofa() {
		
		System.out.println("Sit on Victorian Sofa");
		
	}

}
