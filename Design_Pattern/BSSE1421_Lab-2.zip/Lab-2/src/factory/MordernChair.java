package factory;

public class MordernChair implements Chair{

	@Override
	public void sitOnChair() {
		
		System.out.println("Sit on Mordern Chair");
		
	}

}
