package factory;

public interface Sofa {
     void sitOnSofa();
}
