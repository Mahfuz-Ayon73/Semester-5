package factory;

public interface Chair {
    void sitOnChair();
}
