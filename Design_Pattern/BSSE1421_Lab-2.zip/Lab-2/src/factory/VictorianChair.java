package factory;

public class VictorianChair implements Chair{

	@Override
	public void sitOnChair() {
		
		System.out.println("Sit on Victorian Chair");
		
	}

}
