/**
 * 
 */
/**
 * 
 */
module SingleTon_Pattern {
}