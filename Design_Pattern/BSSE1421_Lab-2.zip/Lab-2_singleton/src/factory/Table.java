package factory;

public interface Table {
     void putOnTable();
     
     String getID();
}
