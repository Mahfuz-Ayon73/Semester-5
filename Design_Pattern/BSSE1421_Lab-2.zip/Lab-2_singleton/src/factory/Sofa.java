package factory;

public interface Sofa {
     void sitOnSofa();
     
     String getID();
}
